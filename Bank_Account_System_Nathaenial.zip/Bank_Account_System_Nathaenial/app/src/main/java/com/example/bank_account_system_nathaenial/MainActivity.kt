package com.example.bank_account_system_nathaenial

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import androidx.appcompat.app.AppCompatActivity
import com.example.bank_account_system_nathaenial.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var account: BankAccount
    private lateinit var binding: ActivityMainBinding
    private val transactions = mutableListOf<Transaction>() // Store transactions

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the layout using View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load balance and transactions from SharedPreferences
        val savedBalance = loadBalance()
        account = BankAccount(savedBalance)
        val savedTransactions = loadTransactions()

        // Add the loaded transactions to the current list
        transactions.addAll(savedTransactions)

        // Set the initial balance display
        updateBalanceDisplay()

        binding.depositButton.setOnClickListener {
            val amount = binding.depositAmountEditText.text.toString().toDoubleOrNull()
            if (amount != null && amount > 0) {
                account.deposit(amount)
                val message = "You have deposited $%.2f into your bank account".format(amount)
                transactions.add(Transaction(getCurrentDateTime(), message)) // Add transaction to the list
                updateBalanceDisplay()
                saveBalance(account.getBalance())  // Save the updated balance
                saveTransactions(transactions)    // Save the updated transactions
                Toast.makeText(this, "Deposit successful!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.invalid_deposit_amount), Toast.LENGTH_SHORT).show()
            }
        }

        binding.withdrawButton.setOnClickListener {
            val amount = binding.withdrawAmountEditText.text.toString().toDoubleOrNull()
            if (amount != null && amount > 0) {
                if (amount <= account.getBalance()) {
                    account.withdraw(amount)
                    val message = "You have withdrawn $%.2f from your bank account".format(amount)
                    transactions.add(Transaction(getCurrentDateTime(), message)) // Add transaction to the list
                    updateBalanceDisplay()
                    saveBalance(account.getBalance())  // Save the updated balance
                    saveTransactions(transactions)    // Save the updated transactions
                    Toast.makeText(this, "Withdrawal successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, getString(R.string.insufficient_balance), Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, getString(R.string.invalid_withdraw_amount), Toast.LENGTH_SHORT).show()
            }
        }

        // View Transaction History button click listener
        binding.viewTransactionButton.setOnClickListener {
            val intent = Intent(this, ViewTransactionHistoryActivity::class.java)
            intent.putParcelableArrayListExtra("transactions", ArrayList(transactions))
            startActivity(intent)
        }
    }

    // Save balance in SharedPreferences
    private fun saveBalance(balance: Double) {
        val sharedPreferences = getSharedPreferences("BankAccountPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putFloat("balance", balance.toFloat())  // Store balance as float
        editor.apply()
    }

    // Load balance from SharedPreferences
    private fun loadBalance(): Double {
        val sharedPreferences = getSharedPreferences("BankAccountPrefs", MODE_PRIVATE)
        return sharedPreferences.getFloat("balance", 0f).toDouble()  // Default to 0.0 if not found
    }

    // Save transactions in SharedPreferences
    private fun saveTransactions(transactions: List<Transaction>) {
        val sharedPreferences = getSharedPreferences("BankAccountPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(transactions)  // Convert list to JSON
        editor.putString("transactions", json)  // Store the JSON string
        editor.apply()
    }

    // Load transactions from SharedPreferences
    private fun loadTransactions(): List<Transaction> {
        val sharedPreferences = getSharedPreferences("BankAccountPrefs", MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("transactions", "[]")  // Default to empty list if not found
        val type = object : TypeToken<List<Transaction>>() {}.type
        return gson.fromJson(json, type)  // Convert JSON back to list
    }

    private fun updateBalanceDisplay() {
        // Format the balance using the string resource
        val balanceText = getString(R.string.balance_format, account.getBalance())
        binding.balanceTextView.text = balanceText
    }

    private fun getCurrentDateTime(): String {
        val formatter = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
        return formatter.format(java.util.Date())
    }
}
