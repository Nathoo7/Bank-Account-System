package com.example.bank_account_system_nathaenial

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.bank_account_system_nathaenial.databinding.TransactionItemBinding

class TransactionAdapter(
    private val transactions: List<Transaction>
) : RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder>() {

    // ViewHolder using binding
    class TransactionViewHolder(val binding: TransactionItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
        // Inflate the layout using View Binding
        val binding = TransactionItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TransactionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
        // Bind data to the ViewHolder
        val transaction = transactions[position]
        holder.binding.transactionMessage.text = "${transaction.timestamp}: ${transaction.message}"
    }

    override fun getItemCount(): Int = transactions.size
}
