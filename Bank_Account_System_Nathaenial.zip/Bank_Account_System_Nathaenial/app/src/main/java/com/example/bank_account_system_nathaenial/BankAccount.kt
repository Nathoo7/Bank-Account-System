package com.example.bank_account_system_nathaenial

class BankAccount(private var balance: Double) {

    // Deposit the given amount to the account
    fun deposit(amount: Double) {
        balance += amount
    }

    // Withdraw the given amount from the account if balance allows
    fun withdraw(amount: Double): Boolean {
        return if (amount <= balance) {
            balance -= amount
            true
        } else {
            false
        }
    }

    // Get the current balance
    fun getBalance(): Double {
        return balance
    }
}
