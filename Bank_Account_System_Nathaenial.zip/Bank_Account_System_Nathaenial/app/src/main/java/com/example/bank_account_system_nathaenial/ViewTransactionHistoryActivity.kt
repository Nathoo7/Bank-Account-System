package com.example.bank_account_system_nathaenial

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bank_account_system_nathaenial.databinding.ActivityViewTransactionHistoryBinding
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ViewTransactionHistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityViewTransactionHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inflate the layout using View Binding
        binding = ActivityViewTransactionHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get the transactions passed from MainActivity using the type-safe API
        val transactions = intent.getParcelableArrayListExtra<Transaction>("transactions") ?: loadTransactions()

        // Set up the RecyclerView
        binding.transactionHistoryRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.transactionHistoryRecyclerView.adapter = TransactionAdapter(transactions)

        // Back Button functionality
        binding.backButton.setOnClickListener {
            // Create an Intent to navigate back to MainActivity
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)  // Start MainActivity
            finish()  // Finish current activity to prevent going back to it
        }
    }

    // Load transactions from SharedPreferences
    private fun loadTransactions(): List<Transaction> {
        val sharedPreferences = getSharedPreferences("BankAccountPrefs", MODE_PRIVATE)
        val gson = Gson()
        val json = sharedPreferences.getString("transactions", "[]")  // Default to empty list if not found
        val type = object : TypeToken<List<Transaction>>() {}.type
        return gson.fromJson(json, type)  // Convert JSON back to list
    }
}
